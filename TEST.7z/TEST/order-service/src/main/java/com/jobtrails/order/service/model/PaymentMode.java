package com.jobtrails.order.service.model;

public enum PaymentMode {
    CASH,
    PAY_PAL,
    DEBIT_CARD,
    CREDIT_CARD,
    APPLE_PAY,
    INTERNET_BANKING
}
