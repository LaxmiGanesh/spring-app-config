package com.jobtrails.order.service.external.client;


import com.jobtrails.order.service.exception.CustomException;
import com.jobtrails.order.service.external.request.PaymentRequest;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CircuitBreaker(name="external",fallbackMethod = "fallback")
@FeignClient(name = "PAYMENT-SERVICE/payment")
public interface PaymentService {

    @PostMapping
    public ResponseEntity<Long> doPayment(@RequestBody PaymentRequest paymentRequest);

    default  ResponseEntity<Long>  fallback(Exception exception){
        throw  new CustomException("payment service is unavailable","PAYMENT_SERVICE_UNAVAILABLE",500);
    }
}
