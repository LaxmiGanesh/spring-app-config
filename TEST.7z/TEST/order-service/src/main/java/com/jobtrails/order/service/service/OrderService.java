package com.jobtrails.order.service.service;

import com.jobtrails.order.service.model.OrderRequest;
import com.jobtrails.order.service.model.OrderResponse;

public interface OrderService {
    long placeOrder(OrderRequest orderRequest);

    OrderResponse getOrderDetails(long orderId);
}
