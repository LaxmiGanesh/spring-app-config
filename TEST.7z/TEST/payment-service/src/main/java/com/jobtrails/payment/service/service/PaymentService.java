package com.jobtrails.payment.service.service;

import com.jobtrails.payment.service.model.PaymentRequest;
import com.jobtrails.payment.service.model.PaymentResponse;
import org.springframework.stereotype.Service;


public interface PaymentService {
    long doPayment(PaymentRequest paymentRequest);

    PaymentResponse getPaymentDetailsByOrderId(String orderId);
}
