package com.jobtrails.productservice.service;

import com.jobtrails.productservice.model.ProductRequest;
import com.jobtrails.productservice.model.ProductResponse;

public interface ProductService {
    long addProduct(ProductRequest productRequest);

    ProductResponse getProductById(long productId);

    void reduceQuantity(long productId, long quantity);
}
